
asc.jar 
	.as file syntax checking

fdb.jar
	adobe flash player debugger